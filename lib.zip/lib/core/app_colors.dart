class AppColors {

}